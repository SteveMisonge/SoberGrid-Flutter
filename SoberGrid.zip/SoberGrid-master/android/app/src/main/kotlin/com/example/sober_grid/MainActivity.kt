package com.example.sober_grid

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
